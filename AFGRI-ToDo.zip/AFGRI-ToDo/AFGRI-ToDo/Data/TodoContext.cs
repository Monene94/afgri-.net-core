﻿using AFGRI_ToDo.Models;
using Microsoft.EntityFrameworkCore;

namespace AFGRI_ToDo.Data
{
    public class TodoContext : DbContext
    {
        public TodoContext(DbContextOptions<TodoContext> options) : base(options) { }

        public DbSet<Todo> Todos { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Todo>().HasData(
                new Todo { Id = 1, Title = "Buy groceries", IsComplete = false },
                new Todo { Id = 2, Title = "Complete .NET task", IsComplete = false }
            );
        }
    }
}
